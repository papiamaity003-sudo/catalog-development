import 'package:hive/hive.dart';

part 'product.g.dart';

@HiveType(typeId: 1)
class Product extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String description;

  @HiveField(3)
  String? mainImagePath;

  @HiveField(4)
  List<String> galleryImagePaths;

  @HiveField(5)
  double wholesalePrice;

  @HiveField(6)
  double? mrp;

  @HiveField(7)
  int? minQty;

  @HiveField(8)
  String categoryId;

  @HiveField(9)
  Map<String, List<String>> variations;

  @HiveField(10)
  String? sku;

  // ✅ New fields for optimized images
  @HiveField(11)
  String? mainThumbPath;

  @HiveField(12)
  List<String> galleryThumbPaths;

  Product({
    required this.id,
    required this.name,
    this.description = '',
    this.mainImagePath,
    this.galleryImagePaths = const [],
    required this.wholesalePrice,
    this.mrp,
    this.minQty,
    required this.categoryId,
    this.variations = const {},
    this.sku,
    this.mainThumbPath, // ✅ add
    this.galleryThumbPaths = const [], // ✅ add
  });
}
