// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ProductAdapter extends TypeAdapter<Product> {
  @override
  final int typeId = 1;

  @override
  Product read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Product(
      id: fields[0] as String,
      name: fields[1] as String,
      description: fields[2] as String,
      mainImagePath: fields[3] as String?,
      galleryImagePaths: (fields[4] as List).cast<String>(),
      wholesalePrice: fields[5] as double,
      mrp: fields[6] as double?,
      minQty: fields[7] as int?,
      categoryId: fields[8] as String,
      variations: (fields[9] as Map).map((dynamic k, dynamic v) =>
          MapEntry(k as String, (v as List).cast<String>())),
      sku: fields[10] as String?,
      mainThumbPath: fields[11] as String?,
      galleryThumbPaths: (fields[12] as List).cast<String>(),
    );
  }

  @override
  void write(BinaryWriter writer, Product obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.mainImagePath)
      ..writeByte(4)
      ..write(obj.galleryImagePaths)
      ..writeByte(5)
      ..write(obj.wholesalePrice)
      ..writeByte(6)
      ..write(obj.mrp)
      ..writeByte(7)
      ..write(obj.minQty)
      ..writeByte(8)
      ..write(obj.categoryId)
      ..writeByte(9)
      ..write(obj.variations)
      ..writeByte(10)
      ..write(obj.sku)
      ..writeByte(11)
      ..write(obj.mainThumbPath)
      ..writeByte(12)
      ..write(obj.galleryThumbPaths);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ProductAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
