import 'package:hive/hive.dart';

part 'company.g.dart';

@HiveType(typeId: 3)
class Company extends HiveObject {
  @HiveField(0)
  String name;
  @HiveField(1)
  String? logoPath;
  @HiveField(2)
  String? address;
  @HiveField(3)
  String? mobile;
  @HiveField(4)
  String? email;
  @HiveField(5)
  String? website;

  Company({
    required this.name,
    this.logoPath,
    this.address,
    this.mobile,
    this.email,
    this.website,
  });
}
