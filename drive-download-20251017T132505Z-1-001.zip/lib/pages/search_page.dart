import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/product.dart';
import 'product_detail_page.dart';
import '../services/hive_boxes.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _controller = TextEditingController();
  List<Product> _results = [];

  void _search(String query) {
    final allProducts = Boxes.getProducts().values.toList();
    setState(() {
      _results = allProducts
          .where((p) => (p.name.toLowerCase().contains(query.toLowerCase()) ||
              (p.sku?.toLowerCase().contains(query.toLowerCase()) ?? false)))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Products'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _controller,
              decoration: const InputDecoration(
                hintText: 'Search by name or SKU',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: _search,
            ),
          ),
          Expanded(
            child: ValueListenableBuilder(
              valueListenable: Hive.box<Product>('products').listenable(),
              builder: (context, Box<Product> box, _) {
                return ListView.builder(
                  itemCount: _results.length,
                  itemBuilder: (context, index) {
                    final product = _results[index];
                    final img = (product.mainImagePath != null &&
                            File(product.mainImagePath!).existsSync())
                        ? Image.file(File(product.mainImagePath!),
                            width: 60, height: 60, fit: BoxFit.cover)
                        : Image.asset(
                            'assets/images/placeholder_product.png',
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                          );
                    return ListTile(
                      leading: ClipRRect(
                          borderRadius: BorderRadius.circular(6), child: img),
                      title: Text(product.name),
                      subtitle: Text('SKU: ${product.sku ?? "-"}'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                ProductDetailPage(productId: product.id),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
