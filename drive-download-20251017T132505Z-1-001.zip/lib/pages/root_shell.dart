import 'package:flutter/material.dart';
import '../services/ads_service.dart';
import 'home_page.dart';
import 'add_product_page.dart';
import 'category_page.dart';
import 'settings_page.dart';
import 'download_page.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    AdsService.init();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomePage(),
      const AddProductPage(),
      const CategoryPage(),
      const DownloadPage(),
      const SettingsPage()
    ];
    final titles = [
      'Catalog',
      'Add Product',
      'Categories',
      'Download',
      'Settings'
    ];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (i) => setState(() => index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Add'),
          BottomNavigationBarItem(
              icon: Icon(Icons.category), label: 'Category'),
          BottomNavigationBarItem(icon: Icon(Icons.download), label: 'Catalog'),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
