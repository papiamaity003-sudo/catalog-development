import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/category.dart';
import '../services/hive_boxes.dart';

class CategoryPage extends StatefulWidget {
  const CategoryPage({super.key});

  @override
  State<CategoryPage> createState() => _CategoryPageState();
}

class _CategoryPageState extends State<CategoryPage> {
  @override
  Widget build(BuildContext context) {
    final products = Boxes.getProducts().values.toList();

    int productCount(String catId) =>
        products.where((p) => p.categoryId == catId).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Categories')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openAddCategory(context),
        child: const Icon(Icons.add),
      ),

      // ✅ Listen for category box changes
      body: ValueListenableBuilder(
        valueListenable: Boxes.getCategories().listenable(),
        builder: (context, box, _) {
          final categories = box.values.toList().cast<Category>();

          if (categories.isEmpty) {
            return const Center(child: Text("No categories added yet."));
          }

          return ListView.separated(
            itemCount: categories.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final c = categories[i];
              final count = productCount(c.id);

              return ListTile(
                leading:
                    (c.imagePath != null && File(c.imagePath!).existsSync())
                        ? CircleAvatar(
                            backgroundImage: FileImage(File(c.imagePath!)))
                        : const CircleAvatar(
                            backgroundImage: AssetImage(
                                'assets/images/placeholder_category.png')),
                title: Text(c.name),
                subtitle: Text('$count products'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () => _openAddCategory(context, edit: c),
                    ),
                    if (count == 0)
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => c.delete(),
                      ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _openAddCategory(BuildContext context, {Category? edit}) async {
    final nameCtrl = TextEditingController(text: edit?.name ?? '');
    String? imagePath = edit?.imagePath;
    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(edit == null ? 'Add Category' : 'Edit Category'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'Category Name *'),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  (imagePath != null && File(imagePath!).existsSync())
                      ? CircleAvatar(
                          backgroundImage: FileImage(File(imagePath!)))
                      : const CircleAvatar(
                          backgroundImage: AssetImage(
                              'assets/images/placeholder_category.png')),
                  const SizedBox(width: 12),
                  TextButton.icon(
                    onPressed: () async {
                      final x = await ImagePicker()
                          .pickImage(source: ImageSource.gallery);
                      if (x != null) {
                        setState(() {
                          imagePath = x.path;
                        });
                      }
                    },
                    icon: const Icon(Icons.image),
                    label: const Text('Pick Image (optional)'),
                  ),
                ],
              )
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              if (edit == null) {
                final c = Category(
                  id: const Uuid().v4(),
                  name: nameCtrl.text.trim(),
                  imagePath: imagePath,
                );
                await Boxes.getCategories().add(c);
              } else {
                edit.name = nameCtrl.text.trim();
                edit.imagePath = imagePath;
                await edit.save();
              }
              if (context.mounted) Navigator.pop(context);
            },
            child: Text(edit == null ? 'Add' : 'Save'),
          ),
        ],
      ),
    );
  }
}
