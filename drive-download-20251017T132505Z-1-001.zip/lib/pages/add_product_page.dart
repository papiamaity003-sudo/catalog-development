// lib/pages/add_product_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/product.dart';
import '../models/category.dart' as mycat;
import '../services/hive_boxes.dart';

class VariationItem {
  String id;
  TextEditingController nameCtrl;
  TextEditingController valueCtrl;

  VariationItem({required this.id, String? name, String? values})
      : nameCtrl = TextEditingController(text: name ?? ""),
        valueCtrl = TextEditingController(text: values ?? "");
}

class AddProductPage extends StatefulWidget {
  final String? editProductId;
  const AddProductPage({super.key, this.editProductId});

  @override
  State<AddProductPage> createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final formKey = GlobalKey<FormState>();
  final skuCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final descCtrl = TextEditingController();
  final wholesaleCtrl = TextEditingController();
  final mrpCtrl = TextEditingController();
  final minQtyCtrl = TextEditingController();
  final newCategoryCtrl = TextEditingController();

  String? mainImagePath;
  String? mainThumbPath; // ✅ NEW (state)
  List<String> gallery = [];
  List<String> galleryThumbs = []; // ✅ NEW (state)
  String? categoryId;
  List<VariationItem> _variations = [];
  bool creatingCategory = false;

  // ---------- loader flag ----------
  bool _isProcessingImage = false;

  @override
  void initState() {
    super.initState();
    if (widget.editProductId != null) {
      final p = Boxes.getProducts()
          .values
          .firstWhere((e) => e.id == widget.editProductId);

      skuCtrl.text = p.sku ?? _generateNextSku();
      nameCtrl.text = p.name;
      descCtrl.text = p.description;
      wholesaleCtrl.text = p.wholesalePrice.toString();
      mrpCtrl.text = p.mrp?.toString() ?? '';
      minQtyCtrl.text = p.minQty?.toString() ?? '';
      mainImagePath = p.mainImagePath;
      mainThumbPath = p.mainThumbPath; // ✅ load thumb if present
      gallery = List.of(p.galleryImagePaths);
      galleryThumbs = List.of(p.galleryThumbPaths); // ✅ load if present
      categoryId = p.categoryId;

      // variations
      _variations.clear();
      p.variations.forEach((k, v) {
        _variations.add(
          VariationItem(
            id: const Uuid().v4(),
            name: k,
            values: v.join(", "),
          ),
        );
      });
    } else {
      skuCtrl.text = _generateNextSku();
    }
  }

  @override
  void dispose() {
    skuCtrl.dispose();
    nameCtrl.dispose();
    descCtrl.dispose();
    wholesaleCtrl.dispose();
    mrpCtrl.dispose();
    minQtyCtrl.dispose();
    newCategoryCtrl.dispose();
    for (final v in _variations) {
      v.nameCtrl.dispose();
      v.valueCtrl.dispose();
    }
    super.dispose();
  }

  String _generateNextSku() {
    final products = Boxes.getProducts().values.toList();
    final maxNum = products.map((p) {
      final sku = p.sku ?? '';
      if (sku.startsWith("PCM")) {
        return int.tryParse(sku.replaceFirst("PCM", "")) ?? 0;
      }
      return 0;
    }).fold<int>(0, (prev, e) => e > prev ? e : prev);

    return "PCM${maxNum + 1}";
  }

  // ---- Thumbnail helper (saves to app documents dir) ----
  Future<String?> _createThumbnail(String originalPath,
      {int maxWidth = 600, int quality = 75}) async {
    try {
      final f = File(originalPath);
      if (!f.existsSync()) return null;
      final bytes = await f.readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return null;

      final resized = decoded.width > maxWidth
          ? img.copyResize(decoded, width: maxWidth)
          : decoded;
      final jpg = img.encodeJpg(resized, quality: quality);

      final appDir = await getApplicationDocumentsDirectory();
      final base = p.basenameWithoutExtension(originalPath);
      final thumbPath =
          p.join(appDir.path, "${base}_${const Uuid().v4()}_thumb.jpg");
      final out = File(thumbPath);
      await out.writeAsBytes(jpg, flush: true);
      return out.path;
    } catch (_) {
      return null;
    }
  }

  // Ensures a thumb exists; returns existing or newly created
  Future<String?> _ensureThumb(String? maybeThumb, String? original) async {
    if (maybeThumb != null && File(maybeThumb).existsSync()) return maybeThumb;
    if (original == null) return null;
    return await _createThumbnail(original);
  }

  @override
  Widget build(BuildContext context) {
    final categories = Boxes.getCategories().values.toList();

    return Stack(
      children: [
        Scaffold(
          appBar: AppBar(
            title: Text(
                widget.editProductId == null ? 'Add Product' : 'Edit Product'),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: formKey,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextFormField(
                      controller: skuCtrl,
                      readOnly: true,
                      decoration: const InputDecoration(
                          labelText: 'SKU (auto-generated)'),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: nameCtrl,
                      decoration:
                          const InputDecoration(labelText: 'Product Name *'),
                      validator: (v) =>
                          v == null || v.trim().isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: descCtrl,
                      decoration:
                          const InputDecoration(labelText: 'Description'),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 8),

                    // Main image picker (unchanged UI, loader added around processing)
                    Row(children: [
                      (mainImagePath != null &&
                              File(mainImagePath!).existsSync())
                          ? Image.file(File(mainImagePath!),
                              width: 100, height: 100, fit: BoxFit.cover)
                          : Image.asset('assets/images/placeholder_product.png',
                              width: 100, height: 100, fit: BoxFit.cover),
                      const SizedBox(width: 12),
                      TextButton.icon(
                        onPressed: () async {
                          final x = await ImagePicker()
                              .pickImage(source: ImageSource.gallery);
                          if (x != null) {
                            // show loader while processing
                            setState(() {
                              _isProcessingImage = true;
                              mainImagePath = x.path;
                            });

                            try {
                              final t = await _createThumbnail(x.path);
                              if (!mounted) return;
                              setState(() {
                                mainThumbPath = t;
                              });
                            } catch (e) {
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content:
                                          Text('Image processing failed: $e')),
                                );
                              }
                            } finally {
                              if (mounted) {
                                setState(() {
                                  _isProcessingImage = false;
                                });
                              }
                            }
                          }
                        },
                        icon: const Icon(Icons.image),
                        label: const Text('Pick Main Image'),
                      ),
                    ]),
                    const SizedBox(height: 8),

                    // Gallery
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      for (final pth in gallery)
                        Stack(children: [
                          Image.file(File(pth),
                              width: 90, height: 90, fit: BoxFit.cover),
                          Positioned(
                            right: 0,
                            top: 0,
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  final idx = gallery.indexOf(pth);
                                  if (idx >= 0 && idx < galleryThumbs.length) {
                                    galleryThumbs
                                        .removeAt(idx); // keep lists aligned
                                  }
                                  gallery.remove(pth);
                                });
                              },
                              child: const CircleAvatar(
                                  radius: 12,
                                  child: Icon(Icons.close, size: 14)),
                            ),
                          ),
                        ]),
                      OutlinedButton.icon(
                        onPressed: () async {
                          final xs = await ImagePicker().pickMultiImage();
                          if (xs.isNotEmpty) {
                            // show loader while processing
                            setState(() {
                              _isProcessingImage = true;
                              gallery.addAll(xs.map((e) => e.path));
                            });

                            try {
                              // Generate thumbs asynchronously, keep order
                              for (final e in xs) {
                                final t = await _createThumbnail(e.path);
                                if (!mounted) return;
                                setState(() {
                                  galleryThumbs
                                      .add(t ?? ""); // keep index alignment
                                });
                              }
                            } catch (e) {
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content: Text(
                                          'Gallery image processing failed: $e')),
                                );
                              }
                            } finally {
                              if (mounted) {
                                setState(() {
                                  _isProcessingImage = false;
                                });
                              }
                            }
                          }
                        },
                        icon: const Icon(Icons.collections),
                        label: const Text('Add Gallery Images'),
                      ),
                    ]),
                    const SizedBox(height: 8),

                    TextFormField(
                      controller: wholesaleCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Price *'),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: mrpCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'MRP'),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: minQtyCtrl,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(labelText: 'Minimum Quantity'),
                    ),
                    const SizedBox(height: 8),

                    // Category
                    InputDecorator(
                      decoration:
                          const InputDecoration(labelText: 'Category *'),
                      child: creatingCategory
                          ? Row(children: [
                              Expanded(
                                child: TextField(
                                  controller: newCategoryCtrl,
                                  decoration: const InputDecoration(
                                      hintText: 'New category name'),
                                ),
                              ),
                              TextButton(
                                onPressed: () async {
                                  final name = newCategoryCtrl.text.trim();
                                  if (name.isEmpty) return;
                                  final c = mycat.Category(
                                      id: const Uuid().v4(), name: name);
                                  await Boxes.getCategories().add(c);
                                  setState(() {
                                    categoryId = c.id;
                                    creatingCategory = false;
                                    newCategoryCtrl.clear();
                                  });
                                },
                                child: const Text('Create'),
                              ),
                            ])
                          : DropdownButton<String>(
                              isExpanded: true,
                              value: categoryId,
                              items: [
                                ...categories.map((c) => DropdownMenuItem(
                                    value: c.id, child: Text(c.name))),
                                const DropdownMenuItem(
                                    value: '_create',
                                    child: Text('➕ Create Category'))
                              ],
                              onChanged: (v) => setState(() {
                                if (v == '_create') {
                                  creatingCategory = true;
                                } else {
                                  categoryId = v;
                                }
                              }),
                              hint: const Text('Select category'),
                            ),
                    ),
                    const SizedBox(height: 8),

                    // Variations
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Variations'),
                          TextButton.icon(
                            onPressed: _addVariation,
                            icon: const Icon(Icons.add),
                            label: const Text('Add Variation'),
                          ),
                        ]),
                    Column(
                      children: _variations
                          .map((v) => _buildVariationTile(v))
                          .toList(),
                    ),

                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _save,
                        child: Text(widget.editProductId == null
                            ? 'Add Product'
                            : 'Save Changes'),
                      ),
                    ),
                  ]),
            ),
          ),
        ),
        // ---------- loader overlay ----------
        if (_isProcessingImage)
          Container(
            color: Colors.black.withOpacity(0.45),
            child: const Center(
              child: SizedBox(
                width: 72,
                height: 72,
                child: CircularProgressIndicator(strokeWidth: 6),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildVariationTile(VariationItem item) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(children: [
          Row(children: [
            Expanded(
              child: TextField(
                controller: item.nameCtrl,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(
                    labelText: 'Variation Name (e.g., Color)'),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () => setState(() => _variations.remove(item)),
            ),
          ]),
          TextField(
            controller: item.valueCtrl,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              labelText: 'Variation Values (comma separated, e.g., Red, Blue)',
            ),
          ),
        ]),
      ),
    );
  }

  void _addVariation() {
    setState(() {
      _variations.add(VariationItem(id: const Uuid().v4()));
    });
  }

  Future<void> _save() async {
    if (!formKey.currentState!.validate()) return;
    if (categoryId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select or create a category.')),
      );
      return;
    }

    // Show loader
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Center(child: CircularProgressIndicator()),
      ),
    );

    try {
      // Ensure thumbs exist (covers edit mode & older products)
      if (mainImagePath != null) {
        mainThumbPath = await _ensureThumb(mainThumbPath, mainImagePath);
      }

      // Keep galleryThumbs aligned with gallery; fill missing ones
      final fixedThumbs = <String>[];
      for (var i = 0; i < gallery.length; i++) {
        final orig = gallery[i];
        String? maybeThumb =
            (i < galleryThumbs.length && galleryThumbs[i].isNotEmpty)
                ? galleryThumbs[i]
                : null;
        final ensured = await _ensureThumb(maybeThumb, orig);
        fixedThumbs.add(ensured ?? "");
      }
      galleryThumbs = fixedThumbs;

      // Build variations map
      final variations = <String, List<String>>{};
      for (final v in _variations) {
        if (v.nameCtrl.text.trim().isNotEmpty &&
            v.valueCtrl.text.trim().isNotEmpty) {
          variations[v.nameCtrl.text.trim()] =
              v.valueCtrl.text.split(",").map((e) => e.trim()).toList();
        }
      }

      if (widget.editProductId == null) {
        // NEW product
        final product = Product(
          id: const Uuid().v4(),
          sku: skuCtrl.text.trim(),
          name: nameCtrl.text.trim(),
          description: descCtrl.text.trim(),
          mainImagePath: mainImagePath,
          galleryImagePaths: List<String>.from(gallery),
          wholesalePrice: double.tryParse(wholesaleCtrl.text.trim()) ?? 0,
          mrp: mrpCtrl.text.isEmpty
              ? null
              : double.tryParse(mrpCtrl.text.trim()),
          minQty: minQtyCtrl.text.isEmpty
              ? null
              : int.tryParse(minQtyCtrl.text.trim()),
          categoryId: categoryId!,
          variations: variations,

          // ✅ thumbnails
          mainThumbPath: mainThumbPath,
          galleryThumbPaths: galleryThumbs.where((e) => e.isNotEmpty).toList(),
        );

        await Boxes.getProducts().add(product);
      } else {
        // EDIT existing
        final existing = Boxes.getProducts()
            .values
            .firstWhere((e) => e.id == widget.editProductId);

        existing
          ..sku = skuCtrl.text.trim()
          ..name = nameCtrl.text.trim()
          ..description = descCtrl.text.trim()
          ..mainImagePath = mainImagePath
          ..galleryImagePaths = List<String>.from(gallery)
          ..wholesalePrice = double.tryParse(wholesaleCtrl.text.trim()) ?? 0
          ..mrp =
              mrpCtrl.text.isEmpty ? null : double.tryParse(mrpCtrl.text.trim())
          ..minQty = minQtyCtrl.text.isEmpty
              ? null
              : int.tryParse(minQtyCtrl.text.trim())
          ..categoryId = categoryId!
          ..variations = variations

          // ✅ thumbnails
          ..mainThumbPath = mainThumbPath
          ..galleryThumbPaths =
              galleryThumbs.where((e) => e.isNotEmpty).toList();

        await existing.save();
      }

      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop(); // close loader

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Product saved successfully!')),
      );

      // Reset form fields for next add
      setState(() {
        skuCtrl.text = _generateNextSku();
        nameCtrl.clear();
        descCtrl.clear();
        wholesaleCtrl.clear();
        mrpCtrl.clear();
        minQtyCtrl.clear();
        mainImagePath = null;
        mainThumbPath = null;
        gallery.clear();
        galleryThumbs.clear();
        categoryId = null;
        _variations.clear();
        creatingCategory = false;
      });
    } catch (e) {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving product: $e')),
      );
    }
  }
}
