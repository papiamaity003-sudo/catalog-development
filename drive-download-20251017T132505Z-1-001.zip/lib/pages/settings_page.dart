import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/company.dart';
import '../models/category.dart';
import '../models/product.dart';
import '../services/hive_boxes.dart';
import '../services/export_import_service.dart';
import '../widgets/ad_banner_widget.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  File? _lastExportedFile; // ✅ store last exported file for sharing

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 🔹 WhatsApp Banner
            InkWell(
              onTap: () async {
                final url = Uri.parse(
                    'https://wa.me/916295736101?text=${Uri.encodeComponent("I want a business Website")}');
                if (await canLaunchUrl(url)) {
                  await launchUrl(url, mode: LaunchMode.externalApplication);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Could not open WhatsApp')),
                  );
                }
              },
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    image: const DecorationImage(
                      image: AssetImage(
                          'assets/images/optimus_banner.png'), // your banner image
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ✅ Company Info
            ValueListenableBuilder(
              valueListenable: Boxes.getCompany().listenable(),
              builder: (context, box, _) {
                final company = box.isNotEmpty
                    ? box.values.first as Company
                    : Company(name: 'Your Company');

                return ListTile(
                  leading: (company.logoPath != null &&
                          File(company.logoPath!).existsSync())
                      ? CircleAvatar(
                          backgroundImage: FileImage(File(company.logoPath!)))
                      : const CircleAvatar(
                          backgroundImage:
                              AssetImage('assets/images/dummy_logo.png'),
                        ),
                  title: Text(company.name),
                  subtitle: Text(
                    [company.mobile, company.email]
                        .whereType<String>()
                        .where((e) => e.isNotEmpty)
                        .join(' • '),
                  ),
                  trailing: ElevatedButton(
                    onPressed: () => _editCompany(context, company),
                    child: const Text('Edit'),
                  ),
                );
              },
            ),

            const Divider(),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _exportData,
                          icon: const Icon(Icons.upload_file),
                          label: const Text('Export Data'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _importData,
                          icon: const Icon(Icons.download),
                          label: const Text('Import Data'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _shareData,
                    icon: const Icon(Icons.share),
                    label: const Text('Share Exported File'),
                  ),
                ],
              ),
            ),
            const AdBannerWidget(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // ------------------------------
  // ✅ Edit Company Dialog
  // ------------------------------
  Future<void> _editCompany(BuildContext context, Company c) async {
    final name = TextEditingController(text: c.name);
    final addr = TextEditingController(text: c.address ?? '');
    final mob = TextEditingController(text: c.mobile ?? '');
    final email = TextEditingController(text: c.email ?? '');
    final web = TextEditingController(text: c.website ?? '');
    String? logo = c.logoPath;
    final formKey = GlobalKey<FormState>();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Company'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: name,
                  decoration:
                      const InputDecoration(labelText: 'Company Name *'),
                  validator: (v) =>
                      v == null || v.trim().isEmpty ? 'Required' : null,
                ),
                TextFormField(
                    controller: addr,
                    decoration: const InputDecoration(labelText: 'Address')),
                TextFormField(
                    controller: mob,
                    decoration: const InputDecoration(labelText: 'Mobile')),
                TextFormField(
                    controller: email,
                    decoration: const InputDecoration(labelText: 'Email')),
                TextFormField(
                    controller: web,
                    decoration: const InputDecoration(labelText: 'Website')),
                const SizedBox(height: 8),
                Row(
                  children: [
                    (logo != null && File(logo!).existsSync())
                        ? CircleAvatar(backgroundImage: FileImage(File(logo!)))
                        : const CircleAvatar(
                            backgroundImage:
                                AssetImage('assets/images/dummy_logo.png')),
                    const SizedBox(width: 12),
                    TextButton.icon(
                      onPressed: () async {
                        final x = await ImagePicker()
                            .pickImage(source: ImageSource.gallery);
                        if (x != null) {
                          setState(() {
                            logo = x.path;
                          });
                        }
                      },
                      icon: const Icon(Icons.image),
                      label: const Text('Pick Logo'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;

              c
                ..name = name.text.trim()
                ..address = addr.text.trim()
                ..mobile = mob.text.trim()
                ..email = email.text.trim()
                ..website = web.text.trim()
                ..logoPath = logo;

              if (c.isInBox) {
                await c.save();
              } else {
                await Boxes.getCompany().add(c);
              }

              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  // ------------------------------
  // ✅ Export
  // ------------------------------
  Future<void> _exportData() async {
    try {
      final file = await ExportImportService.exportToFile(
        products: Boxes.getProducts().values.toList(),
        categories: Boxes.getCategories().values.toList(),
        company: Boxes.getCompany().isNotEmpty
            ? Boxes.getCompany().values.first
            : null,
      );

      if (!mounted) return;

      if (file != null) {
        _lastExportedFile = file;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✅ Exported to: ${file.path}')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('⚠️ Export failed')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Export error: $e')),
      );
    }
  }

  // ------------------------------
  // ✅ Import
  // ------------------------------
  Future<void> _importData() async {
    final data = await ExportImportService.pickAndReadJson();
    if (data == null) return;

    await Boxes.getProducts().clear();
    await Boxes.getCategories().clear();
    await Boxes.getCompany().clear();

    for (final c in (data['categories'] as List)) {
      await Boxes.getCategories().add(Category(
        id: c['id'],
        name: c['name'],
        imagePath: c['imagePath'],
      ));
    }

    for (final p in (data['products'] as List)) {
      await Boxes.getProducts().add(Product(
        id: p['id'],
        name: p['name'],
        description: p['description'] ?? '',
        mainImagePath: p['mainImagePath'],
        galleryImagePaths: (p['galleryImagePaths'] as List).cast<String>(),
        wholesalePrice: (p['wholesalePrice'] as num).toDouble(),
        mrp: (p['mrp'] as num?)?.toDouble(),
        minQty: p['minQty'],
        categoryId: p['categoryId'],
        variations: (p['variations'] as Map).map(
          (k, v) => MapEntry(
            k.toString(),
            (v as List).map((e) => e.toString()).toList(),
          ),
        ),
      ));
    }

    if (data['company'] != null) {
      final c = data['company'];
      await Boxes.getCompany().add(Company(
        name: c['name'],
        logoPath: c['logoPath'],
        address: c['address'],
        mobile: c['mobile'],
        email: c['email'],
        website: c['website'],
      ));
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('✅ Import complete')),
    );
  }

  // ------------------------------
  // ✅ Share
  // ------------------------------
  Future<void> _shareData() async {
    if (_lastExportedFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('⚠️ No exported file found. Export first!')),
      );
      return;
    }

    try {
      await ExportImportService.shareFile(_lastExportedFile!);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Share failed: $e')),
      );
    }
  }
}
