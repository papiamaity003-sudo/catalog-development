import 'dart:io';
import 'package:flutter/material.dart';
import '../services/hive_boxes.dart';
import '../services/pdf_service.dart';
import 'add_product_page.dart';

class ProductDetailPage extends StatelessWidget {
  final String productId;
  const ProductDetailPage({super.key, required this.productId});

  /// 🔹 Helper to show loader while generating PDF
  Future<void> _generatePdfWithLoader(
    BuildContext context, {
    required Future<void> Function() task,
  }) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    try {
      await task();
    } finally {
      Navigator.of(context).pop(); // close loader
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = Boxes.getProducts().values.firstWhere((e) => e.id == productId);
    final cat =
        Boxes.getCategories().values.firstWhere((c) => c.id == p.categoryId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Details'),
        backgroundColor: const Color(0xFF0F4C43),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Main Image
            Container(
              width: double.infinity,
              height: 240,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.grey[200],
                image: DecorationImage(
                  image: (p.mainImagePath != null &&
                          File(p.mainImagePath!).existsSync())
                      ? FileImage(File(p.mainImagePath!))
                      : const AssetImage(
                              'assets/images/placeholder_product.png')
                          as ImageProvider,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Product Name
            Text(
              p.name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),

            // SKU & Category
            Row(
              children: [
                if (p.sku != null && p.sku!.isNotEmpty)
                  Text("SKU: ${p.sku}",
                      style: const TextStyle(color: Colors.grey, fontSize: 14)),
                const SizedBox(width: 16),
                Text(cat.name,
                    style: const TextStyle(color: Colors.grey, fontSize: 14)),
              ],
            ),
            const SizedBox(height: 12),

            // Prices
            Row(
              children: [
                Text(
                  'Price: ${p.wholesalePrice.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 12),
                if (p.mrp != null)
                  Text(
                    'MRP: ${p.mrp!.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                      decoration: TextDecoration.lineThrough,
                    ),
                  ),
              ],
            ),
            if (p.minQty != null) Text('Minimum Qty: ${p.minQty}'),
            const SizedBox(height: 12),

            // Description
            if (p.description.isNotEmpty)
              Text(
                p.description,
                style: const TextStyle(fontSize: 14),
              ),
            const SizedBox(height: 12),

            // Variations
            if (p.variations.isNotEmpty) ...[
              const Text(
                "Variations:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                children: p.variations.entries.map((e) {
                  final key = e.key;
                  final values = e.value.join(", ");
                  return Chip(
                    backgroundColor: Colors.green[100],
                    label: Text("$key: $values"),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
            ],

            // Gallery
            if (p.galleryImagePaths.isNotEmpty) ...[
              const Text(
                "Gallery:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              SizedBox(
                height: 100,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: p.galleryImagePaths.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) {
                    final g = p.galleryImagePaths[i];
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(g),
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AddProductPage(editProductId: p.id),
                      ),
                    ),
                    icon: const Icon(Icons.edit),
                    label: const Text(
                      'Edit Product',
                      style: TextStyle(color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0F4C43)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      final company = Boxes.getCompany().isNotEmpty
                          ? Boxes.getCompany().values.first
                          : null;

                      await _generatePdfWithLoader(
                        context,
                        task: () => PdfService.buildCatalogPdf(
                          company: company, // ✅ pass company correctly
                          products: [p],
                          catById: {cat.id: cat},
                          fileName: 'product_${p.id}.pdf',
                          shareAfterSave: true,
                        ),
                      );
                    },
                    icon: const Icon(Icons.share),
                    label: const Text('Share Product'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
