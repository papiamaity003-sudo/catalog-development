import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'root_shell.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final controller = PageController();
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: controller,
                onPageChanged: (i) => setState(() => index = i),
                children: const [
                  _OnboardScreen(
                      image: 'assets/images/onboard1.png',
                      title: 'Welcome',
                      text:
                          'Create and share your B2B product catalog easily.'),
                  _OnboardScreen(
                      image: 'assets/images/onboard2.png',
                      title: 'Grow Faster',
                      text: 'Share via PDF on WhatsApp, SMS or any app.'),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(onPressed: _finish, child: const Text('Skip')),
                  Row(
                      children: List.generate(
                          2,
                          (i) => Container(
                              margin: const EdgeInsets.all(4),
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: i == index
                                      ? Colors.green
                                      : Colors.grey)))),
                  ElevatedButton(
                    onPressed: () {
                      if (index == 1) {
                        _finish();
                      } else {
                        controller.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut);
                      }
                    },
                    child: Text(index == 1 ? 'Start' : 'Next'),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<void> _finish() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('seen_onboarding', true);
    if (!mounted) return;
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (_) => const RootShell()));
  }
}

class _OnboardScreen extends StatelessWidget {
  final String image;
  final String title;
  final String text;
  const _OnboardScreen(
      {required this.image, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        children: [
          const SizedBox(height: 40),
          Image.asset(image, height: 280),
          const SizedBox(height: 24),
          Text(title,
              style:
                  const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(text, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
