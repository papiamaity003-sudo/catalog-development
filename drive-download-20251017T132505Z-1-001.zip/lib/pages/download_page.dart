import 'dart:io';
import 'package:flutter/material.dart';
import '../services/hive_boxes.dart';
import '../services/pdf_service.dart';
import '../services/ads_service.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class DownloadPage extends StatefulWidget {
  const DownloadPage({super.key});

  @override
  State<DownloadPage> createState() => _DownloadPageState();
}

class _DownloadPageState extends State<DownloadPage> {
  bool _isGenerating = false;
  bool _isLoadingAd = false;

  @override
  void initState() {
    super.initState();
    AdsService.init(); // Initialize Google Mobile Ads
  }

  Future<void> _generatePdfWithLoader(Future<void> Function() task) async {
    setState(() => _isGenerating = true);
    try {
      await task();
    } finally {
      setState(() => _isGenerating = false);
    }
  }

  Future<void> _showRewardedAdAndGeneratePdf(
      Future<void> Function() pdfTask) async {
    setState(() => _isLoadingAd = true);

    RewardedAd.load(
      adUnitId: AdsService.rewardedUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          setState(() => _isLoadingAd = false);

          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) async {
              ad.dispose();
              await _generatePdfWithLoader(pdfTask);
            },
            onAdFailedToShowFullScreenContent: (ad, error) async {
              ad.dispose();
              await _generatePdfWithLoader(pdfTask);
            },
          );

          // Show the ad
          ad.show(onUserEarnedReward: (ad, reward) {});
        },
        onAdFailedToLoad: (error) async {
          setState(() => _isLoadingAd = false);
          // If ad fails to load, generate PDF immediately
          await _generatePdfWithLoader(pdfTask);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final products = Boxes.getProducts().values.toList();
    final categories = Boxes.getCategories().values.toList();
    final company =
        Boxes.getCompany().isNotEmpty ? Boxes.getCompany().values.first : null;
    final catById = {for (final c in categories) c.id: c};

    return Scaffold(
      appBar: AppBar(title: const Text('Download / Share Catalog PDF')),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                ElevatedButton.icon(
                  onPressed: () async {
                    await _showRewardedAdAndGeneratePdf(
                      () => PdfService.buildCatalogPdf(
                        company: company,
                        products: products,
                        catById: catById,
                        fileName: 'catalog_all.pdf',
                        shareAfterSave: true,
                      ),
                    );
                  },
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Share All Catalog'),
                ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: () async {
                    final ids = await _pickCategories(context);
                    if (ids.isEmpty) return;

                    final prods = products
                        .where((p) => ids.contains(p.categoryId))
                        .toList();

                    await _showRewardedAdAndGeneratePdf(
                      () => PdfService.buildCatalogPdf(
                        company: company,
                        products: prods,
                        catById: catById,
                        fileName: 'catalog_selected.pdf',
                        shareAfterSave: true,
                      ),
                    );
                  },
                  icon: const Icon(Icons.category),
                  label: const Text('Share Category-wise Catalog'),
                ),
              ],
            ),
          ),

          // Overlay when ad is loading or PDF generating
          if (_isGenerating || _isLoadingAd)
            Container(
              color: Colors.black54,
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 12),
                    Text(
                      "Loading... Please wait",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<List<String>> _pickCategories(BuildContext context) async {
    final categories = Boxes.getCategories().values.toList();
    final picked = <String>{};

    final result = await showDialog<List<String>>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Select Categories'),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: categories.length,
                itemBuilder: (_, i) {
                  final c = categories[i];
                  final sel = picked.contains(c.id);
                  return CheckboxListTile(
                    value: sel,
                    onChanged: (v) {
                      setState(() {
                        if (v == true) {
                          picked.add(c.id);
                        } else {
                          picked.remove(c.id);
                        }
                      });
                    },
                    title: Text(c.name),
                  );
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, <String>[]),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, picked.toList()),
                child: const Text('OK'),
              ),
            ],
          );
        },
      ),
    );

    return result ?? [];
  }
}
