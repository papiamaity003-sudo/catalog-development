import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../models/product.dart';
import '../models/category.dart';
import '../models/company.dart';
import '../services/hive_boxes.dart';
import '../services/pdf_service.dart';
import '../services/ads_service.dart';
import '../widgets/product_card.dart';
import '../widgets/category_slider.dart';
import '../widgets/ad_banner_widget.dart';
import 'product_detail_page.dart';
import 'add_product_page.dart';
import 'settings_page.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'search_page.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? selectedCategoryId;
  bool gridView = true;
  bool _isGenerating = false;
  bool _isAdLoading = false; // ← flag for ad loading overlay

  @override
  void initState() {
    super.initState();
    AdsService.init(); // Initialize Google Mobile Ads
  }

  @override
  Widget build(BuildContext context) {
    final categoryBox = Boxes.getCategories();
    final companyBox = Boxes.getCompany();
    final company = companyBox.isNotEmpty ? companyBox.values.first : null;

    ImageProvider companyLogo;
    if (company?.logoPath != null && File(company!.logoPath!).existsSync()) {
      companyLogo = FileImage(File(company.logoPath!));
    } else {
      companyLogo = const AssetImage('assets/images/dummy_logo.png');
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F4C43),
        title: Row(
          children: [
            CircleAvatar(backgroundImage: companyLogo),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(company?.name ?? 'Your Company',
                      style:
                          const TextStyle(fontSize: 16, color: Colors.white)),
                  const Text('Welcome to Product Catalog Maker',
                      style: TextStyle(fontSize: 12, color: Colors.white70)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchPage()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsPage()),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isGenerating || _isAdLoading
            ? null
            : () {
                final products = Boxes.getProducts().values.toList();
                final categories = categoryBox.values.toList();
                final catById = {for (final c in categories) c.id: c};
                _showRewardedAdAndShareCatalog(
                    context, company, products, catById);
              },
        label: const Text('High Quality Catalog'),
        icon: const Icon(Icons.ios_share),
        backgroundColor: const Color.fromARGB(255, 13, 105, 91),
        foregroundColor: const Color.fromARGB(255, 255, 255, 255),
      ),
      body: Stack(
        children: [
          ValueListenableBuilder(
            valueListenable: Hive.box<Product>('products').listenable(),
            builder: (context, Box<Product> box, _) {
              final products = box.values.toList();
              final filtered = selectedCategoryId == null
                  ? products
                  : products
                      .where((p) => p.categoryId == selectedCategoryId)
                      .toList();
              final categories = categoryBox.values.toList();
              final catById = {for (final c in categories) c.id: c};

              return Column(
                children: [
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _StatCard(
                            title: 'Products',
                            value: products.length.toString()),
                        _StatCard(
                          title: 'Categories',
                          value: categories.length.toString(),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  _CategoriesList(categories: categories),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(
                              gridView ? Icons.grid_view : Icons.view_list),
                          onPressed: () => setState(() => gridView = !gridView),
                          tooltip: 'Toggle Grid/List',
                        )
                      ],
                    ),
                  ),
                  CategorySlider(
                    categories: categories,
                    selectedId: selectedCategoryId,
                    onSelected: (id) => setState(() => selectedCategoryId = id),
                  ),
                  const Divider(height: 1),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: gridView
                          ? GridView.builder(
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                childAspectRatio: .72,
                                crossAxisSpacing: 8,
                                mainAxisSpacing: 8,
                              ),
                              itemCount: filtered.length,
                              itemBuilder: (_, i) {
                                final p = filtered[i];
                                return ProductCard(
                                  product: p,
                                  onTap: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          ProductDetailPage(productId: p.id),
                                    ),
                                  ),
                                  onEdit: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          AddProductPage(editProductId: p.id),
                                    ),
                                  ),
                                  onDelete: () => p.delete(),
                                );
                              },
                            )
                          : ListView.separated(
                              itemCount: filtered.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 8),
                              itemBuilder: (_, i) {
                                final p = filtered[i];
                                final img = (p.mainImagePath != null &&
                                        File(p.mainImagePath!).existsSync())
                                    ? Image.file(File(p.mainImagePath!),
                                        width: 90,
                                        height: 90,
                                        fit: BoxFit.cover)
                                    : Image.asset(
                                        'assets/images/placeholder_product.png',
                                        width: 90,
                                        height: 90,
                                        fit: BoxFit.cover,
                                      );
                                return ListTile(
                                  leading: ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: img,
                                  ),
                                  title: Text(p.name),
                                  subtitle: Text(
                                    'Price: ${p.wholesalePrice.toStringAsFixed(2)}',
                                  ),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.edit),
                                        onPressed: () => Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => AddProductPage(
                                                editProductId: p.id),
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete),
                                        onPressed: () => p.delete(),
                                      ),
                                    ],
                                  ),
                                  onTap: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          ProductDetailPage(productId: p.id),
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                  ),
                  const AdBannerWidget(),
                  const SizedBox(height: 6),
                ],
              );
            },
          ),

          // 🔹 Loading overlay for PDF generation or Ad loading
          if (_isGenerating || _isAdLoading)
            Container(
              color: Colors.black54,
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 12),
                    Text(
                      "Loading... Please wait",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _shareCatalog(BuildContext context, Company? company,
      List<Product> products, Map<String, Category> catById) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            title: const Text('Share All Catalog (PDF)'),
            onTap: () => Navigator.pop(context, 'all'),
          ),
          ListTile(
            title: const Text('Share Category-wise (PDF)'),
            onTap: () => Navigator.pop(context, 'category'),
          ),
          ListTile(
            title: const Text('Cancel'),
            onTap: () => Navigator.pop(context),
          ),
        ]),
      ),
    );

    if (choice == null) return;

    setState(() => _isGenerating = true);

    try {
      if (choice == 'all') {
        await PdfService.buildCatalogPdf(
          company: company,
          products: Boxes.getProducts().values.toList(),
          catById: catById,
          fileName: 'catalog_all.pdf',
          shareAfterSave: true,
        );
      } else {
        final selected = await _pickCategories(context);
        if (selected.isNotEmpty) {
          final ids = selected.map((e) => e.id).toSet();
          final prods = Boxes.getProducts()
              .values
              .where((p) => ids.contains(p.categoryId))
              .toList();

          await PdfService.buildCatalogPdf(
            company: company,
            products: prods,
            catById: catById,
            fileName: 'catalog_selected.pdf',
            shareAfterSave: true,
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error generating PDF: $e")),
        );
      }
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }

  Future<List<Category>> _pickCategories(BuildContext context) async {
    final categories = Boxes.getCategories().values.toList();
    final picked = <String>{};

    final result = await showDialog<List<String>>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Select Categories'),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: categories.length,
                itemBuilder: (_, i) {
                  final c = categories[i];
                  final sel = picked.contains(c.id);
                  return CheckboxListTile(
                    value: sel,
                    onChanged: (v) {
                      setState(() {
                        if (v == true) {
                          picked.add(c.id);
                        } else {
                          picked.remove(c.id);
                        }
                      });
                    },
                    title: Text(c.name),
                  );
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, null),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, picked.toList()),
                child: const Text('OK'),
              ),
            ],
          );
        },
      ),
    );

    if (result == null) return [];
    return categories.where((c) => result.contains(c.id)).toList();
  }

  // ⭐ Helper function to load Rewarded Ad before sharing catalog
  Future<void> _showRewardedAdAndShareCatalog(
      BuildContext context,
      Company? company,
      List<Product> products,
      Map<String, Category> catById) async {
    setState(() => _isAdLoading = true);

    RewardedAd.load(
      adUnitId: AdsService.rewardedUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          setState(() => _isAdLoading = false);

          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) async {
              ad.dispose();
              await _shareCatalog(context, company, products, catById);
            },
            onAdFailedToShowFullScreenContent: (ad, error) async {
              ad.dispose();
              await _shareCatalog(context, company, products, catById);
            },
          );

          ad.show(onUserEarnedReward: (ad, reward) {});
        },
        onAdFailedToLoad: (error) async {
          setState(() => _isAdLoading = false);
          await _shareCatalog(context, company, products, catById);
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final VoidCallback? onTap;
  const _StatCard({required this.title, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: 70,
          decoration: BoxDecoration(
            color: const Color(0xFFE8F3F0),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(
                value,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(title),
            ]),
          ),
        ),
      ),
    );
  }
}

class _CategoriesList extends StatelessWidget {
  final List<Category> categories;
  const _CategoriesList({required this.categories});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Categories')),
      body: ListView.separated(
        itemCount: categories.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) => ListTile(title: Text(categories[i].name)),
      ),
    );
  }
}
