import 'dart:io';
import 'package:flutter/material.dart';
import '../models/product.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const ProductCard(
      {super.key,
      required this.product,
      required this.onTap,
      required this.onEdit,
      required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final img = (product.mainImagePath != null &&
            File(product.mainImagePath!).existsSync())
        ? Image.file(File(product.mainImagePath!), fit: BoxFit.cover)
        : Image.asset('assets/images/placeholder_product.png',
            fit: BoxFit.cover);
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
                child: ClipRRect(
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(16)),
                    child: img)),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text('Price: ${product.wholesalePrice.toStringAsFixed(2)}'),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                            icon: const Icon(Icons.edit),
                            onPressed: onEdit,
                            tooltip: 'Edit'),
                        IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: onDelete,
                            tooltip: 'Delete'),
                      ],
                    )
                  ]),
            ),
          ],
        ),
      ),
    );
  }
}
