import 'dart:io';
import 'package:flutter/material.dart';
import '../models/category.dart';

class CategorySlider extends StatelessWidget {
  final List<Category> categories;
  final String? selectedId;
  final ValueChanged<String?> onSelected;
  const CategorySlider({super.key, required this.categories, required this.selectedId, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 110,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemBuilder: (_, i) {
          final c = categories[i];
          final selected = c.id == selectedId;
          final img = (c.imagePath != null && File(c.imagePath!).existsSync())
              ? CircleAvatar(radius: 32, backgroundImage: FileImage(File(c.imagePath!)))
              : const CircleAvatar(radius: 32, backgroundImage: AssetImage('assets/images/placeholder_category.png'));
          return Column(
            children: [
              InkWell(
                onTap: () => onSelected(selected ? null : c.id),
                child: Container(
                  decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: selected ? Colors.green.shade800 : Colors.transparent, width: 3)),
                  child: img,
                ),
              ),
              const SizedBox(height: 6),
              SizedBox(width: 80, child: Text(c.name, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis)),
            ],
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemCount: categories.length,
      ),
    );
  }
}
