import 'package:hive/hive.dart';
import '../models/product.dart';
import '../models/category.dart';
import '../models/company.dart';

class Boxes {
  static Box<Product> getProducts() => Hive.box<Product>('products');
  static Box<Category> getCategories() => Hive.box<Category>('categories');
  static Box<Company> getCompany() => Hive.box<Company>('company');
}
