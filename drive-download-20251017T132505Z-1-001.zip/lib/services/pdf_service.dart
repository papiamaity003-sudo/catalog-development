// lib/services/pdf_service.dart
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

import '../models/company.dart';
import '../models/product.dart';
import '../models/category.dart' as mycat;

class PdfService {
  // Lightweight cache: avoids re-reading same files repeatedly
  static final Map<String, pw.MemoryImage> _imageCache = {};

  // Adjust if you want to split gigantic catalogs across multiple MultiPages
  static const int _productsPerChunk = 120;

  /// Build catalog PDF (keeps your original signature/behavior)
  static Future<File> buildCatalogPdf({
    required Company? company,
    required List<Product> products,
    required Map<String, mycat.Category> catById,
    required String fileName,
    bool shareAfterSave = false,
  }) async {
    final doc = pw.Document();

    // Load logo (no recompress, just bytes → MemoryImage)
    final pw.ImageProvider? logo = (company?.logoPath != null)
        ? await _loadImageFast(company!.logoPath!)
        : null;

    // Split to avoid building thousands of widgets at once
    for (int i = 0; i < products.length; i += _productsPerChunk) {
      final chunk = products.sublist(
        i,
        (i + _productsPerChunk > products.length)
            ? products.length
            : i + _productsPerChunk,
      );

      // Pre-read only this chunk’s images (thumbs preferred)
      final optimized = <_OptimizedProduct>[];
      for (final p in chunk) {
        final pw.MemoryImage? mainImg = await _loadPreferredImageFast(
          preferred: p.mainThumbPath,
          fallback: p.mainImagePath,
        );

        final galleryImgs = <pw.MemoryImage>[];
        final List<String> preferredList =
            (p.galleryThumbPaths.isNotEmpty) ? p.galleryThumbPaths : [];
        final List<String> fallbackList =
            (p.galleryImagePaths.isNotEmpty) ? p.galleryImagePaths : [];

        if (preferredList.isNotEmpty) {
          for (final path in preferredList) {
            final gi = await _loadImageFast(path);
            if (gi != null) galleryImgs.add(gi);
          }
        } else {
          // Old records without thumbs
          for (final path in fallbackList) {
            final gi = await _loadImageFast(path);
            if (gi != null) galleryImgs.add(gi);
          }
        }

        optimized.add(_OptimizedProduct(
          product: p,
          mainImg: mainImg,
          gallery: galleryImgs,
        ));
      }

      doc.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(20),
          build: (context) => [
            _header(company, logo),
            pw.SizedBox(height: 16),
            ...optimized.map((op) => _productCard(op, catById)).toList(),
          ],
          footer: (context) => _footer(),
        ),
      );
    }

    // Save
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(await doc.save());

    if (shareAfterSave && await file.exists()) {
      await Share.shareXFiles([XFile(file.path)],
          text: 'Here is the product catalog 📑');
    }
    return file;
  }

  /// Prefer thumbnail path; fallback to original.
  static Future<pw.MemoryImage?> _loadPreferredImageFast({
    String? preferred,
    String? fallback,
  }) async {
    pw.MemoryImage? img;
    if (preferred != null) {
      img = await _loadImageFast(preferred);
      if (img != null) return img;
    }
    if (fallback != null) {
      img = await _loadImageFast(fallback);
    }
    return img;
  }

  /// Read bytes → MemoryImage (no decode/resize/encode)
  static Future<pw.MemoryImage?> _loadImageFast(String path) async {
    if (_imageCache.containsKey(path)) return _imageCache[path];

    final f = File(path);
    if (!f.existsSync()) return null;
    try {
      final bytes = await f.readAsBytes();
      final mem = pw.MemoryImage(bytes);
      _imageCache[path] = mem;
      return mem;
    } catch (_) {
      return null;
    }
  }

  // ---------------- HEADER ----------------
  static pw.Widget _header(Company? company, pw.ImageProvider? logo) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        gradient: pw.LinearGradient(
          colors: [PdfColor.fromInt(0xFF2E7D32), PdfColor.fromInt(0xFF66BB6A)],
        ),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          pw.Container(
            height: 60,
            width: 60,
            decoration: const pw.BoxDecoration(
              shape: pw.BoxShape.circle,
              color: PdfColors.white,
            ),
            child: logo != null
                ? pw.ClipOval(child: pw.Image(logo, fit: pw.BoxFit.cover))
                : pw.Center(
                    child: pw.Text("Logo",
                        style: pw.TextStyle(
                            fontSize: 10, color: PdfColors.grey700))),
          ),
          pw.SizedBox(width: 12),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(company?.name ?? 'COMPANY NAME',
                    style: pw.TextStyle(
                        fontSize: 18,
                        fontWeight: pw.FontWeight.bold,
                        color: PdfColors.white)),
                if ((company?.address ?? '').isNotEmpty)
                  pw.Text(company!.address!,
                      style: const pw.TextStyle(
                          fontSize: 10, color: PdfColors.white)),
              ],
            ),
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              if ((company?.mobile ?? '').isNotEmpty)
                _infoRow("Mob:", company?.mobile ?? ''),
              if ((company?.email ?? '').isNotEmpty)
                _infoRow("Email:", company?.email ?? ''),
              if ((company?.website ?? '').isNotEmpty)
                _infoRow("Web:", company?.website ?? ''),
            ],
          ),
        ],
      ),
    );
  }

  // ---------------- PRODUCT CARD ----------------
  static pw.Widget _productCard(
      _OptimizedProduct op, Map<String, mycat.Category> catById) {
    final p = op.product;
    return pw.Container(
      margin: const pw.EdgeInsets.symmetric(vertical: 10),
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey100,
        border: pw.Border.all(color: PdfColors.grey400),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Container(
            width: 120,
            height: 150,
            color: PdfColors.grey300,
            child: op.mainImg != null
                ? pw.Image(op.mainImg!, fit: pw.BoxFit.cover)
                : pw.Center(
                    child: pw.Text("Product\nImage",
                        textAlign: pw.TextAlign.center,
                        style: const pw.TextStyle(
                            fontSize: 10, color: PdfColors.grey700))),
          ),
          pw.SizedBox(width: 12),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(p.name,
                    style: pw.TextStyle(
                        fontSize: 14, fontWeight: pw.FontWeight.bold)),
                if (p.sku != null && p.sku!.isNotEmpty)
                  pw.Text("SKU: ${p.sku!}",
                      style: const pw.TextStyle(
                          fontSize: 10, color: PdfColors.grey700)),
                if ((p.description).isNotEmpty)
                  pw.Text(p.description,
                      style: const pw.TextStyle(fontSize: 10)),
                pw.SizedBox(height: 6),
                pw.Row(children: [
                  pw.Text("Price: ",
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.Text(p.wholesalePrice.toStringAsFixed(2) + "   "),
                  pw.Text("MRP: ",
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.Text(p.mrp != null
                      ? "${p.mrp!.toStringAsFixed(2)}   "
                      : "-   "),
                  pw.Text("MOQ: ",
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.Text(p.minQty?.toString() ?? "-"),
                ]),
                pw.SizedBox(height: 6),
                if (p.variations.isNotEmpty)
                  pw.Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: p.variations.entries
                        .map((e) => pw.Text("${e.key}: ${e.value.join(", ")}",
                            style: const pw.TextStyle(fontSize: 10)))
                        .toList(),
                  ),
                if (op.gallery.isNotEmpty)
                  pw.Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: op.gallery
                        .map((img) => pw.Container(
                              width: 50,
                              height: 50,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.grey),
                              ),
                              child: pw.Image(img, fit: pw.BoxFit.cover),
                            ))
                        .toList(),
                  ),
              ],
            ),
          )
        ],
      ),
    );
  }

  // ---------------- FOOTER ----------------
  static pw.Widget _footer() {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        gradient: pw.LinearGradient(colors: [
          PdfColor.fromInt(0xFF2E7D32),
          PdfColor.fromInt(0xFF66BB6A)
        ]),
        borderRadius: pw.BorderRadius.circular(6),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Generated: ${DateFormat('dd MMM yyyy, HH:mm').format(DateTime.now())}',
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.white),
          ),
          pw.Text('Generated by Optimuslink.in',
              style: const pw.TextStyle(fontSize: 10, color: PdfColors.white)),
        ],
      ),
    );
  }

  static pw.Widget _infoRow(String label, String text) {
    return pw.Row(mainAxisSize: pw.MainAxisSize.min, children: [
      pw.Text(label,
          style: pw.TextStyle(
              fontSize: 10,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.white)),
      pw.SizedBox(width: 4),
      pw.Text(text,
          style: const pw.TextStyle(fontSize: 10, color: PdfColors.white)),
    ]);
  }
}

class _OptimizedProduct {
  final Product product;
  final pw.MemoryImage? mainImg;
  final List<pw.MemoryImage> gallery;

  _OptimizedProduct({
    required this.product,
    this.mainImg,
    this.gallery = const [],
  });
}
