import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsService {
  static const String realAppId = 'ca-app-pub-6616877427469304~3406801423';
  static String get bannerUnitId =>
      Platform.isAndroid ? 'ca-app-pub-6616877427469304/3190376671' : '';
  static String get interstitialUnitId =>
      Platform.isAndroid ? 'ca-app-pub-6616877427469304/6910129834' : '';
  static String get rewardedUnitId =>
      Platform.isAndroid ? 'ca-app-pub-6616877427469304/4475538182' : '';

  static Future<void> init() async {
    await MobileAds.instance.initialize();
  }

  static BannerAd createBanner(void Function(Ad)? onLoaded) {
    final ad = BannerAd(
      size: AdSize.banner,
      adUnitId: bannerUnitId,
      request: const AdRequest(),
      listener: BannerAdListener(onAdLoaded: onLoaded),
    );
    ad.load();
    return ad;
  }

  static Future<InterstitialAd?> loadInterstitial() async {
    InterstitialAd? ad;
    await InterstitialAd.load(
      adUnitId: interstitialUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (a) => ad = a,
        onAdFailedToLoad: (e) => ad = null,
      ),
    );
    return ad;
  }

  static Future<RewardedAd?> loadRewarded() async {
    RewardedAd? ad;
    await RewardedAd.load(
      adUnitId: rewardedUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (a) => ad = a,
        onAdFailedToLoad: (e) => ad = null,
      ),
    );
    return ad;
  }
}
