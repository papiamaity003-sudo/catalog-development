import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/product.dart';
import '../models/category.dart';
import '../models/company.dart';

class ExportImportService {
  /// ✅ Export data into app’s external directory (/Android/data/your.app/files/Exports)
  static Future<File?> exportToFile({
    required List<Product> products,
    required List<Category> categories,
    required Company? company,
    String fileName = 'catalog_export.json',
  }) async {
    // ✅ Get app-specific external storage directory
    final dir = await getExternalStorageDirectory();
    if (dir == null) throw Exception("Storage directory not found");

    final exportDir = Directory("${dir.path}/Exports");
    if (!await exportDir.exists()) {
      await exportDir.create(recursive: true);
    }

    final file = File('${exportDir.path}/$fileName');

    // ✅ Prepare data
    final data = {
      'products': products
          .map((p) => {
                'id': p.id,
                'name': p.name,
                'description': p.description,
                'sku': p.sku,
                'mainImagePath': p.mainImagePath,
                'galleryImagePaths': p.galleryImagePaths,
                'wholesalePrice': p.wholesalePrice,
                'mrp': p.mrp,
                'minQty': p.minQty,
                'categoryId': p.categoryId,
                'variations': p.variations,
              })
          .toList(),
      'categories': categories
          .map((c) => {
                'id': c.id,
                'name': c.name,
                'imagePath': c.imagePath,
              })
          .toList(),
      'company': company == null
          ? null
          : {
              'name': company.name,
              'logoPath': company.logoPath,
              'address': company.address,
              'mobile': company.mobile,
              'email': company.email,
              'website': company.website,
            }
    };

    // ✅ Write file
    await file.writeAsString(jsonEncode(data));
    return file;
  }

  /// ✅ Pick and import JSON file (from anywhere: Downloads, Drive, WhatsApp, etc.)
  static Future<Map<String, dynamic>?> pickAndReadJson() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
    );

    if (result == null || result.files.single.path == null) return null;

    final file = File(result.files.single.path!);
    final content = await file.readAsString();
    return jsonDecode(content);
  }

  /// ✅ Share JSON file (send via Gmail, WhatsApp, Drive, etc.)
  static Future<void> shareFile(File? file) async {
    if (file == null || !await file.exists()) {
      throw Exception("File not found to share");
    }
    await Share.shareXFiles(
      [XFile(file.path)],
      text: '📦 Catalog Data Export',
    );
  }
}
