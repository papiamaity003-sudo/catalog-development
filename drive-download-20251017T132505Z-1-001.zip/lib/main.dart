import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/product.dart';
import 'models/category.dart';
import 'models/company.dart';
import 'pages/splash.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(ProductAdapter());
  Hive.registerAdapter(CategoryAdapter());
  Hive.registerAdapter(CompanyAdapter());
  await Hive.openBox<Product>('products');
  await Hive.openBox<Category>('categories');
  await Hive.openBox<Company>('company');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const themeColor = Color(0xFF0F4C43); // deep green
    return MaterialApp(
      title: 'Product Catalog Maker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: themeColor,
          primary: themeColor,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: themeColor,
          foregroundColor: Colors.white,
        ),
        // ✅ Make bottom nav clearly visible everywhere
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: themeColor, // deep green bar
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.white70,
          type: BottomNavigationBarType.fixed,
          showSelectedLabels: true,
          showUnselectedLabels: true,
        ),
        useMaterial3: true,
      ),
      home: const SplashPage(),
    );
  }
}
